<center><p>MAU NGAPAIN KONTOL, MAKANYA MODAL NGENTOT</p></center>
<center><p>BUY/SEWA PANEL:</p></center>
<center><p>082231416235</p></center>